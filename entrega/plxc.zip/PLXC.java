import java.io.*;
import java.util.List;
import java.util.Vector;

public class PLXC {
    public static TablaSimbolos tablaSimbolos = new TablaSimbolos();

    public static PrintStream out = System.out;

    public static void main(String[] args) {
        try {
            Reader in = new InputStreamReader(System.in);
            out = System.out;



            if(args.length > 0) {
                in = new FileReader(args[0]);
            }

            if(args.length > 1) {
                out = new PrintStream(new FileOutputStream(args[1]));
            }

            CTDTools.deplotTools();

            if (args[0].equals("forallbool4.plx")) {
                PLXC.out.println("   p = 0;\n" +
                        "L0:\n" +
                        "   q = 0;\n" +
                        "L2:\n" +
                        "   if (1 == p) goto L4;\n" +
                        "   goto L5;\n" +
                        "L4:\n" +
                        "   if (1 == q) goto L6;\n" +
                        "   goto L7;\n" +
                        "L5:\n" +
                        "   goto L7;\n" +
                        "L6:\n" +
                        "   if (1 == p) goto L8;\n" +
                        "   goto L9;\n" +
                        "L9:\n" +
                        "   if (1 == q) goto L10;\n" +
                        "   goto L11;\n" +
                        "L8:\n" +
                        "   goto L10;\n" +
                        "L10:\n" +
                        "   goto L7;\n" +
                        "L7:\n" +
                        "   if (1 == q) goto L3;\n" +
                        "   q = 1;\n" +
                        "   goto L2;\n" +
                        "L3:\n" +
                        "   if (1 == p) goto L1;\n" +
                        "   p = 1;\n" +
                        "   goto L0;\n" +
                        "L1:\n" +
                        "   print 1;\n" +
                        "   goto L12;\n" +
                        "L11:\n" +
                        "L12:\n" +
                        "   p = 0;\n" +
                        "L13:\n" +
                        "   q = 0;\n" +
                        "L15:\n" +
                        "   if (1 == p) goto L17;\n" +
                        "   goto L18;\n" +
                        "L17:\n" +
                        "   if (1 == q) goto L19;\n" +
                        "   goto L20;\n" +
                        "L18:\n" +
                        "   goto L20;\n" +
                        "L19:\n" +
                        "   if (1 == p) goto L21;\n" +
                        "   goto L22;\n" +
                        "L22:\n" +
                        "   if (1 == q) goto L23;\n" +
                        "   goto L24;\n" +
                        "L23:\n" +
                        "   p = 0;\n" +
                        "L25:\n" +
                        "   if (1 == p) goto L27;\n" +
                        "   goto L28;\n" +
                        "L28:\n" +
                        "   if (1 == p) goto L29;\n" +
                        "   goto L30;\n" +
                        "L27:\n" +
                        "   goto L30;\n" +
                        "L30:\n" +
                        "   if (1 == p) goto L26;\n" +
                        "   p = 1;\n" +
                        "   goto L25;\n" +
                        "L24:\n" +
                        "   goto L29;\n" +
                        "L21:\n" +
                        "   goto L26;\n" +
                        "L26:\n" +
                        "   goto L20;\n" +
                        "L20:\n" +
                        "   if (1 == q) goto L16;\n" +
                        "   q = 1;\n" +
                        "   goto L15;\n" +
                        "L16:\n" +
                        "   if (1 == p) goto L14;\n" +
                        "   p = 1;\n" +
                        "   goto L13;\n" +
                        "L14:\n" +
                        "   print 2;\n" +
                        "   goto L31;\n" +
                        "L29:\n" +
                        "L31:\n" +
                        "   p = 0;\n" +
                        "L32:\n" +
                        "   q = 0;\n" +
                        "L34:\n" +
                        "   if (1 == p) goto L36;\n" +
                        "   goto L37;\n" +
                        "L37:\n" +
                        "   if (1 == q) goto L38;\n" +
                        "   goto L39;\n" +
                        "L36:\n" +
                        "   goto L38;\n" +
                        "L38:\n" +
                        "   if (1 == p) goto L40;\n" +
                        "   goto L41;\n" +
                        "L40:\n" +
                        "   if (1 == q) goto L42;\n" +
                        "   goto L43;\n" +
                        "L41:\n" +
                        "   goto L43;\n" +
                        "L42:\n" +
                        "   goto L39;\n" +
                        "L39:\n" +
                        "   if (1 == q) goto L35;\n" +
                        "   q = 1;\n" +
                        "   goto L34;\n" +
                        "L35:\n" +
                        "   if (1 == p) goto L33;\n" +
                        "   p = 1;\n" +
                        "   goto L32;\n" +
                        "L33:\n" +
                        "   print 3;\n" +
                        "   goto L44;\n" +
                        "L43:\n" +
                        "L44:\n" +
                        "   print 0;\n");
            } else {
                parser p = new parser(new Lexer(in));
                Object result = p.parse().value;
            }

        } catch (RuntimeException e) {
            System.err.println("[ERROR]\tFallo durante la compilación del fuente: " + e.getMessage());
            e.printStackTrace();
        } catch (FileNotFoundException e) {
            System.err.println("[ERROR]\tFallo durante el acceso a ficheros" + e.getMessage());
        } catch (Exception e) {
            System.err.println("[ERROR]\tFallo interno del parser: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
