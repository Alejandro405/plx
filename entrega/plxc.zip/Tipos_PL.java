
public enum Tipos_PL {
    INT, BOOL, CHAR, STRING, FLOAT
}
