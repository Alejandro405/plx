import java.util.ArrayList;
import java.util.Objects;

public abstract class Objeto implements Comparable<Objeto>{

    private String nombre;
    private Integer bloque;
    private Boolean mutable;

    private static Integer numObj = 0;

    public Objeto(String nombre, Integer bloque, Boolean mutable) {
        this.nombre = nombre;
        this.bloque = bloque;
        this.mutable = mutable;
    }

    public static String newNombreObjeto() {
        String res = "$R".concat(Integer.toString(numObj));
        numObj++;

        return res;
    }

    public abstract Objeto aplica(String metodo, ArrayList<Objeto> params);

    public String getNombreBloque() {
        return this.bloque == 0 ? nombre: nombre + "$" + bloque;
    }

    public String getNombre() {
        return nombre;
    }

    public Integer getBloque() {
        return bloque;
    }

    public Boolean getMutable() {
        return mutable;
    }

    public static void errorYPara(String msg, ArrayList<Objeto> params) {
        PLXC.out.println("error;\nhalt;");
        // cuando se lancé la excepcion se ejecutara el comando ls -l para ver el estado de los ficheros
        throw new RuntimeException(msg + "\n" + params.toString());
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Objeto objeto = (Objeto) o;

        return Objects.equals(nombre, objeto.nombre) && Objects.equals(bloque, objeto.bloque);
    }

    @Override
    public int compareTo(Objeto o) {
        int res = this.nombre.compareTo(o.nombre);

        return res == 0 ? (this.bloque - o.bloque) : res;
    }

    @Override
    public String toString() {
        return "Objeto{" +
                "nombre='" + nombre + '\'' +
                ", bloque=" + bloque +
                ", mutable=" + mutable +
                '}';
    }
}