import java.util.*;

public class TablaSimbolos {

    private Map<String, TreeMap<Integer, Objeto>> tabla;

    private Integer numEtiq;
    private Integer etiqSwitch;

    public static Integer bloqueActual = 0;

    private static int contBloque;

    public TablaSimbolos() {
        this.tabla = new HashMap<>();
        this.numEtiq = 0;
        this.etiqSwitch = 0;
    }

    public String getNewEtiq() {
        String res = "L" + numEtiq;
        numEtiq++;

        return res;
    }

    public String getNewEtiqSwitch() {
        String res = "L" + etiqSwitch;
        etiqSwitch++;

        return res;
    }

    public String getCurrentEtiqSwitch() {
        return "L" + etiqSwitch;
    }

    public static Integer newBloque() {
        int aux = bloqueActual;
        contBloque++;
        bloqueActual = contBloque;

        return aux;
    }

    public boolean contains(String nombre) {
        return this.tabla.containsKey(nombre);
    }

    public boolean contains(String nombre, Integer bloque) {
        TreeMap<Integer, Objeto> aux = tabla.get(nombre);
        return aux != null && aux.containsKey(bloque);
    }

    public int gmaxBlock() {
        int res = Integer.MIN_VALUE;
        for (TreeMap<Integer, Objeto> x : this.tabla.values()) {
            if (x.lastKey() > res)
                res = x.firstKey();
        }
        return res;
    }

    public Objeto getObj(String nombre) {
        return this.getObj(nombre, this.gmaxBlock());
    }

    public Objeto getObj(String nombre, Integer bloque) {
        Objeto res = this.tabla.get(nombre).get(bloque);
        return res;
    }

    public void putObj(Objeto o) {
        String nombre = o.getNombre();
        Integer bloque = o.getBloque();

        if (this.tabla.containsKey(nombre)) {
            TreeMap<Integer, Objeto> aux = this.tabla.get(nombre);
            aux.put(bloque, o);
        } else {
            TreeMap<Integer, Objeto> aux = new TreeMap<>();
            aux.put(bloque, o);
            this.tabla.put(nombre, aux);
        }
    }

    public void delBlock(Integer bloque) {
        for (String id : this.tabla.keySet()) {
            TreeMap<Integer, Objeto> aux = this.tabla.get(id);
            aux.remove(bloque);
            if (aux.isEmpty())
                this.tabla.remove(id);
        }
    }

    public void delBlock() {
        this.delBlock(bloqueActual);
    }

}