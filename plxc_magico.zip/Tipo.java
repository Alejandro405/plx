import java.util.ArrayList;

public abstract class Tipo extends Objeto{
    public Tipo(String nombre, Integer bloque, Boolean mutable) {
        super(nombre, bloque, mutable);
    }

    public abstract boolean isParseable(Tipo tipo);

    public abstract boolean isIterable();

    public abstract Objeto aplicaEnInstancia(Objeto o, String m, ArrayList<Objeto> p);

    public abstract Tipo getTipo();

    public abstract Instancia cast(Tipo tarTipo, Instancia valor);
}