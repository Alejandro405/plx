import java.util.ArrayList;

public class TipoArray extends Tipo{

    private Instancia array_iterator;

    public static enum ARRAY_METHODS {
        GET,
        SET,
        PRINT,
        ASIGNA,
        LENGTH
    }

    private static final String DEF_TAM = "10";

    private final String tam;

    private final Tipo tipo;

    public TipoArray(Tipo tipo) {
        super(tipo.getNombre(), 0, false);
        this.tam = DEF_TAM;
        this.tipo = tipo;
        this.array_iterator = new Instancia("__ARRAY__PRINTER__", tipo, 0, true);
    }

    public TipoArray(Tipo tipo, String tam) {
        super(tipo.getNombre(), 0, false);
        this.tam = tam;
        this.tipo = tipo;
        this.array_iterator = new Instancia("__ARRAY__PRINTER__", tipo, 0, true);
    }

    public TipoArray(Tipo tipo, Objeto tam) {
        super(tipo.getNombre(), 0, false);
        this.tam = tam.getNombre();
        this.tipo = tipo;
        this.array_iterator = new Instancia("__ARRAY__PRINTER__", tipo, 0, true);
    }

    public Objeto getElem(Objeto array, Instancia i){
        checkIndex(i);
        Instancia res = new Instancia(this.tipo);

        PLXC.out.println(res.getNombre() + " = " + array.getNombre() + "[" + i.getNombre() + "];");

        return res;
    }

    private void checkIndex(Instancia i) {
        String l = PLXC.tablaSimbolos.getNewEtiq();

        PLXC.out.println("check_index_" + l + ":");
        PLXC.out.println("if (" + i.getNombre() + " < 0) goto error_index_" + l + ";");
        PLXC.out.println("if (" + tam + " < " + i.getNombre() + ") goto error_index_" + l + ";");
        PLXC.out.println("if (" + i.getNombre() + " == " + tam + ") goto error_index_" + l + ";");
        PLXC.out.println("goto end_check_index_" + l + ";");
        PLXC.out.println("error_index_" + l + ":");
        PLXC.out.println("error;\nhalt;");
        PLXC.out.println("end_check_index_" + l + ":");
    }

    public void setElem(Objeto array, Instancia i, Objeto o) {
        checkIndex(i);

        PLXC.out.println(array.getNombre() + "[" + i.getNombre() + "] = " + o.getNombre() + ";");
    }

    public String getTam() {
        return tam;
    }

    @Override
    public boolean isParseable(Tipo tipo) {
        return false;
    }

    @Override
    public boolean isIterable() {
        return true;
    }

    @Override
    public Objeto aplicaEnInstancia(Objeto o, String m, ArrayList<Objeto> p) {
        if (m.equals(ARRAY_METHODS.ASIGNA.name())) {
            if (p.size() != 1)
                Objeto.errorYPara("[ERROR]\tEl método asigna de un array debe recibir un parámetro (array)", new ArrayList<>());

            if (!(p.get(0) instanceof Instancia && ((Instancia) p.get(0)).getTipoInstancia().getClass() == this.getClass()))
                Objeto.errorYPara("[ERROR]\tEl parámetro del método asigna de un array debe ser una instancia de tipo array", new ArrayList<>());

            Instancia dst = (Instancia) o;
            Instancia src = (Instancia) p.get(0);

            String numelem = (((TipoArray)src.getTipoInstancia()).tam);

            checkLength(dst, src);
            addAll(dst, src, numelem);

            return o;
        }

        if (m.equals(ARRAY_METHODS.GET.name())) {
            if (!(p.get(0) instanceof Instancia && ((Instancia) p.get(0)).getTipoInstancia() == TipoInt.getTipoInt()))
                Objeto.errorYPara("[ERROR]\tEl índice de acceso a un array debe ser una instancia de tipo entero", new ArrayList<>());
            Instancia aux = (Instancia) p.get(0);
            return getElem(o, aux);
        }

        if (m.equals(ARRAY_METHODS.SET.name())) {
            if (p.size() != 2)
                Objeto.errorYPara("[ERROR]\tEl método set de un array debe recibir dos parámetros (indice y objeto)", new ArrayList<>());

            if (!(p.get(0) instanceof Instancia && ((Instancia) p.get(0)).getTipoInstancia() == TipoInt.getTipoInt()))
                Objeto.errorYPara("[ERROR]\tEl índice de acceso a un array debe ser una instancia de tipo entero", new ArrayList<>());

            Instancia i = (Instancia) p.get(0);

            setElem(o, i, p.get(1));

            return o;
        }

        if (m.equals(ARRAY_METHODS.PRINT.name())) {
            if (!(o instanceof Instancia && ((Instancia) o).getTipoInstancia().getClass() == this.getClass()))
                Objeto.errorYPara("[ERROR]\tEl objeto a imprimir debe ser una instancia de tipo array", new ArrayList<>());

            assert o instanceof Instancia;
            printArray((Instancia) o);

            return o;
        }

        if (m.equals(ARRAY_METHODS.LENGTH.name())) {
            Instancia res = new Instancia(TipoInt.getTipoInt());
            PLXC.out.println(res.getNombre() + " = " + tam + ";");
            return res;
        }

        errorYPara("[ERROR]\tNo se ha encontrado el método " + m + " para el tipo array", new ArrayList<>());
        return null;
    }

    private void checkLength(Instancia dst, Instancia src) {
        int tamDST = Integer.parseInt(((TipoArray) dst.getTipoInstancia()).tam);
        int tamSRC = Integer.parseInt(((TipoArray) src.getTipoInstancia()).tam);

        if (tamDST < tamSRC){

        }
    }

    public Tipo getTipo() {
        return tipo;
    }

    @Override
    public Instancia cast(Tipo tarTipo, Instancia valor) {
        Objeto.errorYPara("[ERROR]\tNo se puede castear un array", new ArrayList<>());
        return null;
    }

    @Override
    public Objeto aplica(String metodo, ArrayList<Objeto> params) {
        Objeto.errorYPara("[ERROR]\tNo se contemplan métodos para el tipo array", new ArrayList<>());
        return null;
    }

    private void printArray(Instancia array) {
        for (int i = 0; i < Integer.parseInt(tam); i++) {
            PLXC.out.println(array_iterator.getNombre() + " = " + array.getNombre() + "[" + i + "];");
            array_iterator.aplica("PRINT", new ArrayList<>());
        }
    }

    public void addAll(Instancia dstArray, Instancia srcArray, String numElem) {
        for (int i = 0; i < Integer.parseInt(numElem); i++) {
            PLXC.out.println(array_iterator.getNombre() + " = " + srcArray.getNombre() + "[" + i + "];");
            PLXC.out.println(dstArray.getNombre() + "[" + i + "] = " + array_iterator.getNombre() + ";");
        }
    }

    @Override
    public String toString() {
        return "TArray{" +
                "tam=" + tam +
                ", tipo=" + tipo +
                '}';
    }
}