import java.util.ArrayList;
import java.util.List;

public class TipoBool extends Tipo{

    public static enum BOOL_METHODS {
        AND, OR, NOT
    }

    private static final TipoBool T_BOOL = new TipoBool();

    public TipoBool() {
        super(String.valueOf(Tipos_Datos.BOOL), 0, false);
    }

    @Override
    public Objeto aplica(String metodo, ArrayList<Objeto> params) {
        errorYPara("[ERROR]\tNo se puede ejecutar un método sobre un tipo, solo es posible sobre una instancia", params);
        return null;
    }

    @Override
    public boolean isParseable(Tipo tipo) {
        return true;
    }

    @Override
    public boolean isIterable() {
        return false;
    }

    @Override
    public Objeto aplicaEnInstancia(Objeto o, String m, ArrayList<Objeto> p) {
        if (!(o instanceof Instancia))
            errorYPara("[ERROR]\tSolo es posible ejecutar" + m + " sobre una instancia", p);
        if (((Instancia) o).getTipoInstancia() != T_BOOL)
            errorYPara("[ERROR]\tSolo es posible ejecutar" + m + " sobre una instancia de tipo booleano", p);

        if (m.equals(BOOL_METHODS.AND.toString())) {
            checkBinBoolOper(m, p);
            return and(o, p.get(0));
        } else if (m.equals(BOOL_METHODS.OR.toString())) {
            checkBinBoolOper(m, p);
            return or(o, p.get(0));
        } else if (m.equals(BOOL_METHODS.NOT.toString())) {
            return not(o);
        }

        return null;
    }

    @Override
    public Tipo getTipo() {
        return getTipoBool();
    }

    @Override
    public Instancia cast(Tipo tarTipo, Instancia valor) {
        return null;
    }

    private static void checkBinBoolOper(String m, ArrayList<Objeto> p) {
        if (p.size() != 1 && !checkType(p.get(0)))
            errorYPara("[ERROR]\tEl método " + m + " solo acepta un único parámetro de tipo booleano", p);
    }

    private static boolean checkType(Objeto o) {
        return (o.getClass() == Instancia.class
                && ((Instancia)o).getTipoInstancia() == T_BOOL);
    }

    private static Objeto and(Objeto a, Objeto b) {
        if (!checkType(a) || !checkType(b)) {
            errorYPara("Los parámetros de la operación and deben ser de tipo booleano", new ArrayList<>(List.of(a, b)));
        }

        Objeto res = new Instancia(newNombreObjeto(), T_BOOL, TablaSimbolos.bloqueActual, false);
        PLXC.out.println(res.getNombre() + "=" + a.getNombre() + "*" + b.getNombre() + ";");

        return res;
    }

    private static Objeto or(Objeto a, Objeto b) {
        Instancia res = new Instancia(Objeto.newNombreObjeto(), T_BOOL, TablaSimbolos.bloqueActual, false);
        String end_if = PLXC.tablaSimbolos.getNewEtiq();

        a.getNombre();

        PLXC.out.println(res.getNombre() + " = " + a.getNombre() + ";");
        PLXC.out.println("if (" + res.getNombre() + " == 1) goto " + end_if + ";");
        PLXC.out.println(res.getNombre() + " = " + b.getNombre() + ";");
        PLXC.out.println(end_if + ":");

        return res;
    }

    private static Objeto not(Objeto a) {
        Instancia res = new Instancia(Objeto.newNombreObjeto(), T_BOOL, TablaSimbolos.bloqueActual, false);
        String end_l = PLXC.tablaSimbolos.getNewEtiq();

        PLXC.out.println(res.getNombre() + " = 0;");
        PLXC.out.println("if (" + a.getNombre() + " == 1) goto " + end_l + ";");
        PLXC.out.println(res.getNombre() + " = 1;");
        PLXC.out.println(end_l + ":");

        return res;
    }

    public static TipoBool getTipoBool(){
        return T_BOOL;
    }
}