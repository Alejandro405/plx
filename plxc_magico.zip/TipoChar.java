import java.util.ArrayList;
import java.util.List;

public class TipoChar extends Tipo{

    public static enum CHAR_METHODS {
        SUMA, RESTA, DIV, ASIGNA, PRINT
    }
    private static final TipoChar T_CHAR = new TipoChar();

    public TipoChar() {
        super(String.valueOf(Tipos_Datos.CHAR), 0, false);
    }

    private static void checkBinaryOp(String op, ArrayList<Objeto> p) {
        if (p.size() != 1)
            errorYPara("La " + op + " para el tipo entero solo se contempla para dos valores", p);
        if (!sameType(p.get(0)))
            errorYPara("Los parámetros para la " + op + " no son del tipo correcto (se necesitan tipos numéricos): " + p.toString(), p);
    }

    private static boolean sameType(Objeto o ) {
        return (((Instancia)o).getTipoInstancia() == T_CHAR || ((Instancia)o).getTipoInstancia() == TipoInt.getTipoInt())
                && o.getClass() == Instancia.class;
    }

    @Override
    public Objeto aplica(String metodo, ArrayList<Objeto> params) {
        errorYPara("[ERROR]\tNo se contempla [ " + metodo +"] para el tipo char, solo instancias de tipo char.", params);
        return null;
    }

    @Override
    public boolean isParseable(Tipo tipo) {
        return tipo.getTipo() == TipoInt.getTipoInt() || tipo.getTipo() == T_CHAR;
    }

    @Override
    public boolean isIterable() {
        return false;
    }

    @Override
    public Objeto aplicaEnInstancia(Objeto o, String m, ArrayList<Objeto> p) {
        if (!(o instanceof Instancia))  errorYPara("[ERROR]\tNo se contempla [ " + m +"] para el tipo char, solo instancias de tipo char.", p);
        if (((Instancia) o).getTipoInstancia() != T_CHAR) errorYPara("[ERROR]\tEl objeto proporcionado no es una instancia", new ArrayList<>(List.of(o)));

        if (m.equals(CHAR_METHODS.ASIGNA.name())) {
            if (p.size() != 1)
                errorYPara("[ERROR]\tLa asignación entre chars solo se contempla para un valor", p);
            if (!o.getMutable())
                errorYPara("[ERROR]\tEl objeto proporcionado para la asignación entre chars no es mutable", new ArrayList<>(List.of(o)));

            if (((Instancia) p.get(0)).getTipoInstancia() == TipoChar.getTipoChar() || ((Instancia) p.get(0)).getTipoInstancia() == TipoInt.getTipoInt()) {
                PLXC.out.println(o.getNombre() + " = " + p.get(0).getNombre() + ";");
                return o;
            } else {
                errorYPara("[ERROR]\tLa asignación entre chars solo se contempla para un valor", p);
            }
        }

        if (m.equals(CHAR_METHODS.SUMA.name())) {
            Objeto res = null;
            if (p.size() == 1) {
                if (((Instancia) p.get(0)).getTipoInstancia() == T_CHAR)
                    res = concatDosChars(o, p.get(0));
                else if (((Instancia) p.get(0)).getTipoInstancia() == TipoInt.getTipoInt())
                    res = sumaDosChars(o, p.get(0));
                else
                    errorYPara("La [" + m + "] de char solo es posible entre dos char (concatenación) o entre char y entero (suma)", p);
            }

            return res;
        }

        if (m.equals(CHAR_METHODS.RESTA.name())) {
            checkBinaryOp("resta", p);

            return restaDosChars(o, p.get(0));
        }

        if (m.equals(CHAR_METHODS.DIV.name())) {
            checkBinaryOp("división", p);

            Instancia res = new Instancia(TipoInt.getTipoInt());

            PLXC.out.println(res.getNombre() + " = " + o.getNombre() + " / " + p.get(0).getNombre() + ";");

            return res;
        }

        if (m.equals(CHAR_METHODS.PRINT.name())) {
            if (!p.isEmpty())
                errorYPara("La " + m + " para el tipo char solo se contempla para un valor", p);

            PLXC.out.println("printc " + o.getNombre() + ";");
            return null;
        }

        return null;
    }

    @Override
    public Tipo getTipo() {
        return getTipoChar();
    }


    @Override
    public Instancia cast(Tipo tarTipo, Instancia valor) {
        if (tarTipo == TipoChar.getTipoChar()){
            return new Instancia(valor.getNombre(), tarTipo, TablaSimbolos.bloqueActual, false);
        }else if (tarTipo == TipoInt.getTipoInt()) {
            return new Instancia(valor.getNombre(), tarTipo, TablaSimbolos.bloqueActual, false);
        } else if (tarTipo == TipoFloat.getTipoFloat()) {
            Instancia res = new Instancia(tarTipo);
            PLXC.out.println(res.getNombre() + " = (float) " + valor.getNombre() + ";");
            return res;
        } else {
            errorYPara("[ERROR]\tEl objeto proporcionado para la asignación entre chars no es mutable", new ArrayList<>(List.of(valor)));
            return null;
        }
    }

    private Objeto restaDosChars(Objeto o, Objeto objeto) {
        Instancia res = new Instancia(TipoInt.getTipoInt());

        PLXC.out.println(res.getNombre() + " = " + o.getNombre() + " - " + objeto.getNombre() + ";" );

        return res;
    }

    public static TipoChar getTipoChar(){
        return T_CHAR;
    }

    private static Objeto sumaDosChars(Objeto c1, Objeto c2) {
        Objeto res = new Instancia(TipoInt.getTipoInt());

        PLXC.out.println(res.getNombre() + " = " + c1.getNombre() + " + " + c2.getNombre() + ";" );

        return  res;
    }

    private static StringInstancia concatDosChars(Objeto c1, Objeto c2) {
        StringInstancia res = new StringInstancia(String.valueOf(2));

        PLXC.out.println(res.getNombre() + "[0] = " + c1.getNombre() + ";");
        PLXC.out.println(res.getNombre() + "[1] = " + c2.getNombre() + ";");

        return  res;
    }

    public static void main(String[] args) {
        String a = "\\u0061";
        String b = "\\u0043";
        String c = "\\u25b2";

        var l = List.of(a, b, c);

        for (String s : l) {
            System.out.println(s);
        }
    }

}