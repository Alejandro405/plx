import java.util.ArrayList;
import java.util.List;

public class TipoFloat extends Tipo {

    public static enum FLOAT_METHODS {
        ASIGNA, UMENOS, SUMA, RESTA, MULT, DIV, MAYOR, MENOR, MAYOR_IGUAL, MENOR_IGUAL, IGUAL, DISTINTO, PRINT
    }

    private static final TipoFloat T_FLOAT = new TipoFloat();

    public TipoFloat() {
        super(String.valueOf(Tipos_Datos.FLOAT), 0, false);
    }

    @Override
    public Objeto aplica(String metodo, ArrayList<Objeto> params) {
        errorYPara("No se puede llamar al método " + metodo + " sobre un tipo float, solo es posible operar sobre instancias", params);
        return null;
    }

    @Override
    public boolean isParseable(Tipo tipo) {
        return true;
    }

    @Override
    public boolean isIterable() {
        return false;
    }

    @Override
    public Objeto aplicaEnInstancia(Objeto o, String m, ArrayList<Objeto> p) {
        if (!(o instanceof Instancia)) errorYPara("Error de tipo, el objeto no es una instancia", p);
        if (((Instancia) o).getTipoInstancia() != T_FLOAT)
            errorYPara("Error de tipo, el objto sí es una instancia pero no es un entero", p);

        if (m.equals(FLOAT_METHODS.ASIGNA.name())) {
            if (!(p.size() == 1 && sameType(p.get(0))))
                errorYPara("La asignación solo opera con un argumento de tipo entero", p);
            if (!o.getMutable())
                errorYPara("La variable sobre la que se realizó la asignación no es mutable", new ArrayList<>(List.of(o, p.get(0))));
            Objeto valor = p.get(0);
            PLXC.out.println(o.getNombre() + " = " + valor.getNombre() + ";");

            return o;
        }

        if (m.equals(FLOAT_METHODS.SUMA.name())) {
            checkBinaryOp(p, m);

            Instancia res = new Instancia(Objeto.newNombreObjeto(),T_FLOAT, TablaSimbolos.bloqueActual, false);
            PLXC.out.println(res.getNombre() + "=" + o.getNombre() + " +r " + p.get(0).getNombre() + ";");

            return res;
        }

        if (m.equals(FLOAT_METHODS.RESTA.name())) {
            checkBinaryOp(p, m);

            Instancia res = new Instancia(Objeto.newNombreObjeto(),T_FLOAT, TablaSimbolos.bloqueActual, false);
            PLXC.out.println(res.getNombre() + " = " + o.getNombre() + " -r " + p.get(0).getNombre() + ";");

            return res;
        }

        if (m.equals(FLOAT_METHODS.MULT.name())) {
            checkBinaryOp(p, m);

            Instancia res = new Instancia(Objeto.newNombreObjeto(),T_FLOAT, TablaSimbolos.bloqueActual, false);
            PLXC.out.println(res.getNombre() + " = " + o.getNombre() + " *r " + p.get(0).getNombre() + ";");

            return res;
        }

        if (m.equals(FLOAT_METHODS.DIV.name())) {
            checkBinaryOp(p, m);

            Instancia res = new Instancia(TipoInt.getTipoInt());

            PLXC.out.println(res.getNombre() + " = " + o.getNombre() + " /r " + p.get(0).getNombre() + ";");

            return res;
        }

        if (m.equals(FLOAT_METHODS.UMENOS.name())) {
            if (!p.isEmpty())
                errorYPara("La operación " + m + " no opera con argumentos", p);

            Instancia res = new Instancia(Objeto.newNombreObjeto(),T_FLOAT, TablaSimbolos.bloqueActual, false);
            PLXC.out.println(res.getNombre() + " = 0 -r " + o.getNombre() + ";");

            return res;
        }

        if (m.equals(FLOAT_METHODS.MAYOR.name())) {
            checkBinaryOp(p, m);
            // Implement the method here
        }

        if (m.equals(FLOAT_METHODS.MENOR.name())) {
            checkBinaryOp(p, m);
            // Implement the method here
        }

        if (m.equals(FLOAT_METHODS.MAYOR_IGUAL.name())) {
            checkBinaryOp(p, m);
            // Implement the method here
        }

        if (m.equals(FLOAT_METHODS.MENOR_IGUAL.name())) {
            checkBinaryOp(p, m);
            // Implement the method here
        }

        if (m.equals(FLOAT_METHODS.IGUAL.name())) {
            checkBinaryOp(p, m);
            // Implement the method here
        }

        if (m.equals(FLOAT_METHODS.DISTINTO.name())) {
            checkBinaryOp(p, m);
            // Implement the method here
        }

        if (m.equals(FLOAT_METHODS.PRINT.name())) {
            if (!p.isEmpty())
                errorYPara("La operación " + m + " no opera con argumentos", p);

            PLXC.out.println("print " + o.getNombre() + " ;");

            return null;
        }

        errorYPara("El método " + m + " no está definido para el tipo float", p);

        return null;
    }

    @Override
    public Tipo getTipo() {
        return T_FLOAT;
    }

    @Override
    public Instancia cast(Tipo tarTipo, Instancia valor) {
        if (tarTipo == TipoInt.getTipoInt() || tarTipo == TipoChar.getTipoChar()) {
            Instancia res = new Instancia(tarTipo);
            PLXC.out.println(res.getNombre() + " = (int) " + valor.getNombre() + ";");
            return res;
        } else {
            errorYPara("[ERROR]\tNo se contempla el casting de float a " + tarTipo.getTipo(), new ArrayList<>(List.of(valor)));
            return null;
        }
    }

    private void checkBinaryOp(ArrayList<Objeto> p, String m) {
        if (p.size() != 1 )
            errorYPara("La operación " + m + " solo opera con un argumento de tipo entero", p);

        if (!sameType(p.get(0)))
            errorYPara("Los argumentos para la " + m + "no son del tipo correcto (se necesitan tipos numéricos)", p);
    }

    public static TipoFloat getTipoFloat() {
        return T_FLOAT;
    }

    private static boolean sameType(Objeto o) {
        return (((Instancia) o).getTipoInstancia() == TipoInt.getTipoInt() || ((Instancia) o).getTipoInstancia() == T_FLOAT)
                && o.getClass() == Instancia.class;
    }
}