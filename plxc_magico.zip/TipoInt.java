import java.util.ArrayList;
import java.util.List;

public class TipoInt extends Tipo{

    public static enum INT_METHODS {
        ASIGNA, UMENOS, SUMA, RESTA, MULT, DIV, MAYOR, MENOR, MAYOR_IGUAL, MENOR_IGUAL, IGUAL, DISTINTO, PRINT
    }

    private static TipoInt T_INT = new TipoInt();

    private TipoInt() {
        super(String.valueOf(Tipos_Datos.INT), 0, false);
    }

    public Objeto aplica(String metodo, ArrayList<Objeto> params) {
        errorYPara("no se puede ejecutar un método sobre un tipo, solo es posible sobre una instancia", params);
        return null;
    }

    public boolean isParseable(Tipo tarTipo) {
        return true;
    }

    @Override
    public boolean isIterable() {
        return false;
    }

    public Objeto aplicaEnInstancia(Objeto o, String m, ArrayList<Objeto> p) {
        if (!(o instanceof Instancia))  errorYPara("Error de tipo, el objeto no es una instancia", p);
        assert o instanceof Instancia;
        if (((Instancia) o ).getTipoInstancia() != T_INT)    errorYPara("Error de tipo, el objto sí es una instancia pero no es un entero", p);
        if (m.equals(INT_METHODS.ASIGNA.name())) {
            Tipo aux = ((Instancia)p.get(0)).getTipoInstancia();
            if (!(p.size() == 1 && (aux == T_INT || aux == TipoFloat.getTipoFloat())))
                errorYPara("La asignación solo opera con un argumento de tipo entero, será necesario un casteo del valor para asignar", p);
            if (!o.getMutable())
                errorYPara("La variable sobre la que se realizó la asignación no es mutable", new ArrayList<>(List.of(o, p.get(0))));

            Objeto valor = p.get(0);
            if (aux == TipoFloat.getTipoFloat()) {
                // Realiza un cast a int y crea una nueva instancia de TInt
                int valorInt = Math.round(Float.parseFloat(valor.getNombre()));
                valor = new Instancia(String.valueOf(valorInt), T_INT, TablaSimbolos.bloqueActual, false);
            }
            PLXC.out.println(o.getNombre() + " = " + valor.getNombre() + ";");

            return o;
        }

        if (m.equals(INT_METHODS.SUMA.name())) {
            checkBinaryOp(p, "Suma");

            return sumaDosEnteros(o, p.get(0));
        }

        if (m.equals(INT_METHODS.RESTA.name())) {
            checkBinaryOp(p, "Resta");

            return restaDosEnteros(o, p.get(0));
        }

        if (m.equals(INT_METHODS.MULT.name())) {
            checkBinaryOp(p, "Multiplicación");

            return multiplicaDosEnteros(o, p.get(0));
        }

        if (m.equals(INT_METHODS.DIV.name())) {
            checkBinaryOp(p, "Division");

            return divideDosEnteros(o, p.get(0));
        }

        if (m.equals(INT_METHODS.UMENOS.name())) {
            if (!p.isEmpty())
                errorYPara("La función umenos no necesita parámetros", p);

            Instancia cero = new Instancia("0", T_INT, TablaSimbolos.bloqueActual, false);

            return restaDosEnteros(cero, o);
        }

        if (m.equals(INT_METHODS.MAYOR.name())) {
            checkBinaryOp(p, "MAYOR_QUE");

            return mayorQueDosEnteros(o, p.get(0));
        }

        if (m.equals(INT_METHODS.MENOR.name())) {
            checkBinaryOp(p, "MENOR_QUE");

            return menorQueDosEnteros(o, p.get(0));
        }

        if (m.equals(INT_METHODS.MAYOR_IGUAL.name())) {
            checkBinaryOp(p, "MAYOR_IGUAL_QUE");

            return mayorIgualQueDosEnteros(o, p.get(0));
        }

        if (m.equals(INT_METHODS.MENOR_IGUAL.name())) {
            checkBinaryOp(p, "MENOR_IGUAL_QUE");

            return menorIgualQueDosEnteros(o, p.get(0));
        }

        if (m.equals(INT_METHODS.IGUAL.name())) {
            checkBinaryOp(p, "IGUAL_QUE");

            return igualQueDosEnteros(o, p.get(0));
        }

        if (m.equals(INT_METHODS.DISTINTO.name())) {
            checkBinaryOp(p, "DISTINTO_QUE");

            return distintoQueDosEnteros(o, p.get(0));
        }

        if (m.equals(INT_METHODS.PRINT.name())) {
            if (!p.isEmpty())
                errorYPara("La función print no necesita parámetros", p);

            PLXC.out.println("print " + o.getNombre() + " ;");
            return o;
        }

        if (m.equals("INCREMENTA_1")) {
            PLXC.out.println(o.getNombre() + " = " + o.getNombre() + " + 1;");
            return o;
        }

        errorYPara("Operación no contemplada para el tipo entero. La operación en cuestión es [".concat(m).concat("]"), p);

        return null;
    }

    @Override
    public Tipo getTipo() {
        return T_INT;
    }

    @Override
    public Instancia cast(Tipo tarTipo, Instancia valor) {
        if (tarTipo == TipoChar.getTipoChar()) {
            return new Instancia(valor.getNombre(), tarTipo, TablaSimbolos.bloqueActual, false);
        } else if (tarTipo == TipoInt.getTipoInt()) {
            return new Instancia(valor.getNombre(), tarTipo, TablaSimbolos.bloqueActual, false);
        } else if (tarTipo == TipoFloat.getTipoFloat()) {
            // Realiza un cast a float y crea una nueva instancia de TFloat
            float valorFloat = (float) Integer.parseInt(valor.getNombre());
            return new Instancia(String.valueOf(valorFloat), tarTipo, TablaSimbolos.bloqueActual, false);
        } else {
            errorYPara("No se puede castear el tipo entero a ".concat(tarTipo.getNombre()), new ArrayList<>(List.of(valor)));
            return null;
        }
    }

    private void checkBinaryOp(ArrayList<Objeto> p, String m) {
        if (p.size() != 1)
            errorYPara("La " + m + " para el tipo entero solo se contempla para dos valores", p);
        if (!sameType(p.get(0)))
            errorYPara("Los parámetros para la " + m + " no son del tipo correcto (se necesitan tipos numéricos): " + p.toString(), p);
    }

    public static TipoInt getTipoInt() {
        return T_INT;
    }

    private static boolean sameType(Objeto o ) {
        Tipo aux = ((Instancia)o).getTipoInstancia();
        return (aux == T_INT || aux == TipoFloat.getTipoFloat() || aux == TipoChar.getTipoChar())
                && o.getClass() == Instancia.class;
    }


    private static Objeto sumaDosEnteros(Objeto o, Objeto p) {
        Instancia aux = (Instancia) p;
        Instancia obj = null;

        if (aux.getTipoInstancia() == T_INT || aux.getTipoInstancia() == TipoChar.getTipoChar()) {
            obj = new Instancia(Objeto.newNombreObjeto(), T_INT,TablaSimbolos.bloqueActual, false);

            PLXC.out.println(obj.getNombre() + " = " + o.getNombre() + " + " + p.getNombre() + ";");
        } else {
            obj = new Instancia(Objeto.newNombreObjeto(), TipoFloat.getTipoFloat(), TablaSimbolos.bloqueActual, false);
            PLXC.out.println(obj.getNombre() + " = " + o.getNombre() + " +r " + p.getNombre() + ";");
        }
        return obj;
    }

    private static Objeto restaDosEnteros(Objeto o, Objeto p) {
        Instancia result = null;
        Instancia aux = (Instancia) p;
        if (aux.getTipoInstancia() == T_INT || aux.getTipoInstancia() == TipoChar.getTipoChar()) {
            result = new Instancia(Objeto.newNombreObjeto(), T_INT, TablaSimbolos.bloqueActual, false);
            PLXC.out.println(result.getNombre() + " =" + o.getNombre() + " - " + p.getNombre() + " ;");
        } else {
            result = new Instancia(Objeto.newNombreObjeto(), TipoFloat.getTipoFloat(), TablaSimbolos.bloqueActual, false);
            PLXC.out.println(result.getNombre() + " =" + o.getNombre() + " -r " + p.getNombre() + " ;");
        }

        return result;
    }

    private static Objeto divideDosEnteros(Objeto o, Objeto p) {
        Instancia aux =  (Instancia) p;
        Instancia result = null;
        if (aux.getTipoInstancia() == T_INT || aux.getTipoInstancia() == TipoChar.getTipoChar()) {
            result = new Instancia(Objeto.newNombreObjeto(), T_INT, TablaSimbolos.bloqueActual, false);
            PLXC.out.println(result.getNombre() + " =" + o.getNombre() + " / " + p.getNombre() + " ;");
        } else {

            result = new Instancia(Objeto.newNombreObjeto(), TipoFloat.getTipoFloat(), TablaSimbolos.bloqueActual, false);
            PLXC.out.println(result.getNombre() + " =" + o.getNombre() + " /r " + p.getNombre() + " ;");
        }



        return result;
    }

    /**
     * Genera el CTD necesario para realizar la multiplicación entre dos objetos de tipo entero. CTD para la multiplicación de entera de dos valores:
     *    x = a * b;
     *
     * @param o Objeto entero
     * @param p Parámetro de tipo entero para la multiplicación. Solo 1
     * @return Objeto dentro de la tabla de símbolos con el resultado de la operacion <a * b>
     */
    private static Objeto multiplicaDosEnteros(Objeto o, Objeto p) {
        Instancia result = new Instancia(Objeto.newNombreObjeto(), T_INT, TablaSimbolos.bloqueActual, false);
        PLXC.out.println(result.getNombre() + " =" + o.getNombre() + " * " + p.getNombre() + " ;");

        return result;
    }

    /**
     * Genera el CTD necesario para realizar la comparación mayor que entre dos objetos de tipo entero. CTD para la comparación mayor que de dos valores:
     *
     *    result = 1
     *    if b < a goto l;
     *      result = 0;
     *    l:
     *
     * @param a Objeto entero
     * @param b Parámetro de tipo entero para la comparación.
     * @return Objeto dentro de la tabla de símbolos con el resultado de la operacion <a > b>
     */
    private static Objeto mayorQueDosEnteros(Objeto a, Objeto b) {
        return genIfLessThan(b, a);
    }

    /**
     * Genera el CTD necesario para realizar la comparación menor que entre dos objetos de tipo entero. CTD para la comparación menor que de dos valores:
     *
     *    result = 1
     *    if a < b goto l;
     *      result = 0;
     *    l:
     *
     * @param a Objeto entero
     * @param b Parámetro de tipo entero para la comparación.
     * @return Objeto dentro de la tabla de símbolos con el resultado de la operacion <a < b>
     */
    private static Objeto menorQueDosEnteros(Objeto a, Objeto b) {
        return genIfLessThan(a, b);
    }

    /**
     * Genera el CTD necesario para realizar la comparación mayor o igual que entre dos objetos de tipo entero. CTD para la comparación mayor o igual que de dos valores:
     *
     *    result = 1
     *    if b < a goto l;
     *    if a == b goto l;
     *          result = 0;
     *    l:
     *
     * @param a Objeto entero
     * @param b Parámetro de tipo entero para la comparación.
     * @return Objeto dentro de la tabla de símbolos con el resultado de la operacion <a >= b>
     */
    private static Objeto mayorIgualQueDosEnteros(Objeto a, Objeto b) {
        return genIfLessOrEqual(b, a);
    }



    /**
     * Genera el CTD necesario para realizar la comparación menor o igual que entre dos objetos de tipo entero. CTD para la comparación menor o igual que de dos valores:
     *
     *    result = 1
     *    if a < b goto l;
     *    if a == b goto l;
     *          result = 0;
     *    l:
     *
     * @param a Objeto entero
     * @param b Parámetro de tipo entero para la comparación.
     * @return Objeto dentro de la tabla de símbolos con el resultado de la operacion <a <= b>
     */
    private static Objeto menorIgualQueDosEnteros(Objeto a, Objeto b) {
        return genIfLessOrEqual(a, b);
    }

    /**
     * Genera el CTD necesario para realizar la comparación igual que entre dos objetos de tipo entero. CTD para la comparación igual que de dos valores:
     *
     *    result = 1
     *    if a == b goto l;
     *          result = 0;
     *    l:
     *
     * @param a Objeto entero
     * @param b Parámetro de tipo entero para la comparación.
     * @return Objeto dentro de la tabla de símbolos con el resultado de la operacion <a == b>
     */
    private static Objeto igualQueDosEnteros(Objeto a, Objeto b) {
        Instancia res = new Instancia(Objeto.newNombreObjeto(), TipoBool.getTipoBool(), TablaSimbolos.bloqueActual, false);
        String l = PLXC.tablaSimbolos.getNewEtiq();

        PLXC.out.println(res.getNombre() + " = 1;");
        PLXC.out.println("if (" + a.getNombre() + " == " + b.getNombre() + ") goto " + l + ";");
        PLXC.out.println(res.getNombre() + " = 0;");
        PLXC.out.println(l + ":");

        return res;
    }

    /**
     * Genera el CTD necesario para realizar la comparación distinto que entre dos objetos de tipo entero. CTD para la comparación distinto que de dos valores:
     *  result = 1
     *  if a != b goto l;
     *      result = 0;
     *  l:
     *
     * @param a Objeto entero
     * @param b Parámetro de tipo entero para la comparación.
     * @return Objeto dentro de la tabla de símbolos con el resultado de la operacion <a != b>
     */
    private static Objeto distintoQueDosEnteros(Objeto a, Objeto b) {
        Instancia res = new Instancia(TipoBool.getTipoBool());
        String l = PLXC.tablaSimbolos.getNewEtiq();

        PLXC.out.println(res.getNombre() + " = 1;");
        PLXC.out.println("if (" + a.getNombre() + " != " + b.getNombre() + ") goto " + l + ";");
        PLXC.out.println(res.getNombre() + " = 0;");
        PLXC.out.println(l + ":");


        return res;
    }


    private static Instancia genIfLessThan(Objeto a, Objeto b) {
        Instancia res = new Instancia(Objeto.newNombreObjeto(), TipoBool.getTipoBool(), TablaSimbolos.bloqueActual, false);
        String l = PLXC.tablaSimbolos.getNewEtiq();
        PLXC.out.println(res.getNombre() + " = 1;");
        PLXC.out.println("if (" + a.getNombre() + " < " + b.getNombre() + ") goto " + l + ";");
        PLXC.out.println(res.getNombre() + " = 0;");
        PLXC.out.println(l + ":");

        return res;
    }

    private static Instancia genIfLessOrEqual(Objeto a, Objeto b) {
        Instancia res = new Instancia(Objeto.newNombreObjeto(), TipoBool.getTipoBool(), TablaSimbolos.bloqueActual, false);
        String l = PLXC.tablaSimbolos.getNewEtiq();

        PLXC.out.println(res.getNombre() + " = 1;");
        PLXC.out.println("if (" + a.getNombre() + " < " + b.getNombre() + ") goto " + l + ";");
        PLXC.out.println("if (" + a.getNombre() + " == " + b.getNombre() + ") goto " + l + ";");
        PLXC.out.println(res.getNombre() + " = 0;");
        PLXC.out.println(l + ":");
        return res;
    }


}

