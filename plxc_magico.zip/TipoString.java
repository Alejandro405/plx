import java.util.ArrayList;
import java.util.List;

public class TipoString extends Tipo{
    @Override
    public Objeto aplica(String metodo, ArrayList<Objeto> params) {
        return null;
    }

    public static enum STRING_METHODS {
        ASIGNA, PRINT
    }

    private static final TipoString T_STRING = new TipoString();

    private static final Instancia string_iterator = new Instancia("__STRING__ITERATOR__", TipoChar.getTipoChar(), 0, true);

    private String tam;

    public TipoString() {
        super(TipoChar.getTipoChar().getNombre(), 0, false);
        this.tam = "0";
    }

    public static void main(String[] args) {

        String a = "a\\b";
        var b = a.toCharArray();

        for (char c : b) {
            System.out.print(c);
        }
        System.out.println();

    }

    public Objeto metodos(String metodo, ArrayList<Objeto> params) {
        errorYPara("[ERROR]\tNo se puede llamar al método " + metodo + " de un tipo string.", params);
        return null;
    }

    public boolean isParseable(Tipo tipo) {
        return false;
    }

    @Override
    public boolean isIterable() {
        return false;
    }

    @Override
    public Objeto aplicaEnInstancia(Objeto o, String m, ArrayList<Objeto> p) {
        return null;
    }

    public Objeto metodosInstancia(Objeto o, String m, ArrayList<Objeto> p) {
        if (!(o instanceof StringInstancia))
            errorYPara("[ERROR]\tNo se puede llamar al método " + m + " de un tipo string sobre un objeto que no ses una Instancia", new ArrayList<>(List.of(o)));


        StringInstancia targetString = null;
        if (o instanceof StringInstancia) {
            targetString = (StringInstancia) o;
        } else {
            targetString = new StringInstancia(o);
        }

        if (m.equals(STRING_METHODS.ASIGNA.name())) {
            if (p.size() != 1)
                errorYPara("[ERROR]\tEl método asigna de un string debe recibir un único parámetro (string)", new ArrayList<>());

            if (p.get(0).getClass() != StringInstancia.class)
                errorYPara("[ERROR]\tEl método asigna ha de recibir una StringInstance", new ArrayList<>());

            StringInstancia srcString = (StringInstancia) p.get(0);

            return asigna(targetString, srcString);
        }

        if (m.equals(STRING_METHODS.PRINT.name())) {
            if (!p.isEmpty())
                errorYPara("[ERROR]\tEl método print de un string no debe recibir ningún parámetro", new ArrayList<>());
            printString(targetString);
            return targetString;
        }

        errorYPara("[ERROR]\tNo se encontró el método <" + m + "> definido sobre el tipo String", new ArrayList<>());
        return null;
    }

    @Override
    public Tipo getTipo() {
        return T_STRING;
    }

    public Instancia cast(Tipo tarTipo, Instancia valor) {
        errorYPara("[ERROR]\tPor el momento no se puede castear un string", new ArrayList<>());
        return null;
    }

    public static TipoString getInstance(){
        return T_STRING;
    }

    /**
     * Genera el código de tres direccones para concatenar dos strings. Código de tres direcciones para la concatenación de dos strings.
     *
     *
     * @param dstString Cadena de destino
     * @param srcString Cadena de origen.
     * @return Variable en la que se referencia el resultado de la concatenación en el lenguaje de tres direcciones.
     */
    private static Objeto asigna(StringInstancia dstString, StringInstancia srcString) {

        int tamFinal = Integer.parseInt(srcString.getTam());
        for (int i = 0; i <tamFinal; i++) {
            PLXC.out.println(string_iterator.getNombre() + " = " + srcString.getNombre() + "[" + i + "];");
            PLXC.out.println(dstString.getNombre() + "[" + i + "] = " + string_iterator.getNombre() + ";");
        }
        dstString.setTam(String.valueOf(tamFinal));

        return  dstString;
    }

    public static StringInstancia asignaConstante(StringInstancia dstString, char[] charArray) {
        int tam = charArray.length;

        for (int i = 0; i < tam; i++) {
            PLXC.out.println(dstString.getNombre() + "[" + i + "] = " + (int) charArray[i] + ";");
        }


        dstString.setTam(String.valueOf(tam));
        return dstString;
    }

    /**
     * Printeará el strig asociado a la instancia. No se hacen checkeo de ningún tipo, se asume que todo es correcto
     * @param string Cadena a mostrar
     */
    private void printString(StringInstancia string) {
        int tam = Integer.parseInt(string.getTam());

        for (int i = 0; i < tam; i++) {
            PLXC.out.println(string_iterator.getNombre() + " = " + string.getNombre() + "[" + i + "];");
            PLXC.out.println("writec " + string_iterator.getNombre() + ";");
        }

        PLXC.out.println("printc 0;");
    }
}
