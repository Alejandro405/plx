
public enum Tipos_Datos {
    INT, BOOL, CHAR, STRING, FLOAT

}
